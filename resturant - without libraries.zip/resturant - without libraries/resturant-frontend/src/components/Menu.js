// // components/Menu.js
// export default function Menu() {
//     return (
//       <section id="menu" className="py-20 bg-gray-50">
//         <h2 className="text-3xl font-bold mb-4 text-center">Our Menu</h2>
//         <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
//           <div className="card">
//             <h3 className="text-xl font-bold mb-2">Appetizers</h3>
//             <p className="text-gray-700">Explore our delicious starters to begin your culinary journey.</p>
//           </div>
//           <div className="card">
//             <h3 className="text-xl font-bold mb-2">Main Course</h3>
//             <p className="text-gray-700">Our main dishes are crafted with the finest ingredients.</p>
//           </div>
//           <div className="card">
//             <h3 className="text-xl font-bold mb-2">Desserts</h3>
//             <p className="text-gray-700">Indulge in our sweet and delightful desserts.</p>
//           </div>
//         </div>
//       </section>
//     );
//   }
  
"use client";
// src/components/Menu.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Menu = () => {
  const [menuItems, setMenuItems] = useState([]);

  useEffect(() => {
    // Fetch menu items from the backend
    axios.get(`${process.env.REACT_APP_API_URL}/menu/`)
      .then(response => {
        setMenuItems(response.data);
      })
      .catch(error => {
        console.error('Error fetching menu items:', error);
      });
  }, []);

  return (
    <section id="menu" className="p-6 bg-white">
      <h2 className="text-3xl font-bold mb-4">Our Menu</h2>
      <ul>
        {menuItems.map(item => (
          <li key={item.id} className="border-b py-4">
            <h3 className="text-xl font-semibold">{item.name}</h3>
            <p>{item.description}</p>
            <p className="text-red-500">${item.price}</p>
          </li>
        ))}
      </ul>
    </section>
  );
};

export default Menu;
