
"use client";
// components/Hero.js
import Typed from 'typed.js';
import { useEffect, useRef } from 'react';

export default function Hero() {
  const typedRef = useRef(null);

  useEffect(() => {
    const options = {
      strings: ["Welcome to Hot Rock Restaurant", "Experience Fine Dining", "Book Your Table Now"],
      typeSpeed: 50,
      backSpeed: 25,
      backDelay: 1000,
      startDelay: 500,
      loop: true,
    };
    
    const typed = new Typed(typedRef.current, options);

    return () => {
      typed.destroy();
    };
  }, []);

  return (
    <section className="text-center py-20 bg-cover bg-center" style={{ backgroundImage: 'url(/hero-image.jpg)' }}>
      <h1 className="text-4xl font-bold text-white mb-4">
        <span ref={typedRef}></span>
      </h1>
      <p className="text-lg text-white mb-6">Experience the finest cuisine in town</p>
      <a href="#reservations" className="bg-red-500 text-white px-6 py-3 rounded-lg hover:bg-red-600">Make a Reservation</a>
    </section>
  );
}
