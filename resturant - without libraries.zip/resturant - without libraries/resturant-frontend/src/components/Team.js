// components/Team.js
export default function Team() {
    return (
      <section id="team" className="py-20">
        <h2 className="text-3xl font-bold mb-4">Meet the Team</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="card">
            <img src="/team-member-1.jpg" alt="Team Member 1" className="rounded-full w-24 h-24 mx-auto mb-4" />
            <h3 className="text-xl font-bold">John Doe</h3>
            <p className="text-gray-700">CEO</p>
          </div>
          <div className="card">
            <img src="/team-member-2.jpg" alt="Team Member 2" className="rounded-full w-24 h-24 mx-auto mb-4" />
            <h3 className="text-xl font-bold">Jane Smith</h3>
            <p className="text-gray-700">CTO</p>
          </div>
          <div className="card">
            <img src="/team-member-3.jpg" alt="Team Member 3" className="rounded-full w-24 h-24 mx-auto mb-4" />
            <h3 className="text-xl font-bold">Sam Wilson</h3>
            <p className="text-gray-700">Lead Developer</p>
          </div>
        </div>
      </section>
    );
  }
  