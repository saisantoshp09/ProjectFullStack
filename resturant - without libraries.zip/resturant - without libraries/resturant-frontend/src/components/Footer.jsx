// components/Footer.js
export default function Footer() {
  return (
    <footer className="p-4 bg-gray-800 text-white text-center">
      © 2024 Hot Rock Restaurant. All rights reserved. | 123 Main Street, CityName | (123) 456-7890
    </footer>
  );
}
