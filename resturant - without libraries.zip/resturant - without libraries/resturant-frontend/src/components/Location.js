// components/Location.js
export default function Location() {
    return (
      <section id="location" className="py-20">
        <h2 className="text-3xl font-bold mb-4">Our Location</h2>
        <p className="text-gray-700 mb-6">Find us at 123 Main Street, CityName. We look forward to serving you.</p>
        <iframe src="https://maps.google.com/maps?q=123%20Main%20Street&t=&z=13&ie=UTF8&iwloc=&output=embed" className="w-full h-64"></iframe>
      </section>
    );
  }
  