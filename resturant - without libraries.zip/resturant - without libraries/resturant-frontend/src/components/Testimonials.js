// components/Testimonials.js
import { FaQuoteLeft, FaQuoteRight } from 'react-icons/fa';

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-20 bg-gray-50">
      <h2 className="text-3xl font-bold mb-4 text-center">What Our Guests Say</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card p-6 bg-white shadow-lg rounded-lg">
          <FaQuoteLeft className="text-gray-400 text-3xl mb-4" />
          <p className="text-gray-700 mb-4">
            "The best dining experience I've ever had! The food and service were top-notch."
          </p>
          <p className="text-gray-900 font-bold">- Guest Name</p>
          <FaQuoteRight className="text-gray-400 text-3xl mt-4" />
        </div>
        <div className="card p-6 bg-white shadow-lg rounded-lg">
          <FaQuoteLeft className="text-gray-400 text-3xl mb-4" />
          <p className="text-gray-700 mb-4">
            "Absolutely amazing! I highly recommend RestaurantName for any special occasion."
          </p>
          <p className="text-gray-900 font-bold">- Guest Name</p>
          <FaQuoteRight className="text-gray-400 text-3xl mt-4" />
        </div>
        <div className="card p-6 bg-white shadow-lg rounded-lg">
          <FaQuoteLeft className="text-gray-400 text-3xl mb-4" />
          <p className="text-gray-700 mb-4">
            "Delicious food and a beautiful atmosphere. We will definitely be back!"
          </p>
          <p className="text-gray-900 font-bold">- Guest Name</p>
          <FaQuoteRight className="text-gray-400 text-3xl mt-4" />
        </div>
      </div>
    </section>
  );
}
