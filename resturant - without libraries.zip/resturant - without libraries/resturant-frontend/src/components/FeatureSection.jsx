"use client"; 
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const FeatureSection = () => {
  const [features, setFeatures] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8000/api/features/')
      .then(response => setFeatures(response.data))
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  return (
    <section style={{ padding: '50px 0', textAlign: 'center' }}>
      <h2>Features</h2>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {features.map((feature) => (
          <li key={feature.id} style={{ margin: '20px 0' }}>
            <h3>{feature.name}</h3>
            <p>{feature.description}</p>
          </li>
        ))}
      </ul>
    </section>
  );
};

export default FeatureSection;
