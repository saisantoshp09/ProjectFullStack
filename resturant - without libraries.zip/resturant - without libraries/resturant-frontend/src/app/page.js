import './globals.css';
import Header from '../components/Header';
import Hero from '../components/HeroSection';
import About from '../components/About';
import Menu from '../components/Menu';
import Reservations from '../components/Reservations';
import Location from '../components/Location';
import Testimonials from '../components/Testimonials';
import Footer from '../components/Footer';

export default function HomePage() {
  return (
    <html lang="en">
      <body className="bg-gray-100 text-gray-900">
        <div className="min-h-screen flex flex-col justify-between">
          <Header />
          <main className="flex-grow max-w-7xl mx-auto p-6">
            <Hero />
            <About />
            <Menu />
            <Reservations />
            <Location />
            <Testimonials />
          </main>
          <Footer />
        </div>
      </body>
    </html>
  );
}