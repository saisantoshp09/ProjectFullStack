# restaurant/views.py
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Reservation
from .serializers import ReservationSerializer

@api_view(['POST'])
def create_reservation(request):
    print("Received data:", request.data)  # Debug: Print incoming data
    
    serializer = ReservationSerializer(data=request.data)
    
    if serializer.is_valid():
        print("Validated data:", serializer.validated_data)  # Debug: Print validated data
        serializer.save()
        print("Saved data:", serializer.data)  # Debug: Print saved data
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    
    print("Errors:", serializer.errors)  # Debug: Print errors if validation fails
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def list_reservations(request):
    reservations = Reservation.objects.all()
    serializer = ReservationSerializer(reservations, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)

from django.http import JsonResponse
from .models import MenuItem

def menu_items(request):
    items = MenuItem.objects.all().values()
    return JsonResponse(list(items), safe=False)

