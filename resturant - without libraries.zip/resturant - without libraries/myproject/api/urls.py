# api/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('menu/', views.menu_items, name='menu_items'),
    path('reservations/', views.list_reservations, name='list_reservations'),
    path('reservations/create/', views.create_reservation, name='create_reservation'),
]
