"use client";
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const API_URL = 'http://localhost:8000/api'; // Directly specify API URL

const Reservation = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [guests, setGuests] = useState('');
  const [message, setMessage] = useState('');
  const [reservations, setReservations] = useState([]);

  // Fetch all reservations
  useEffect(() => {
    const fetchReservations = async () => {
      try {
        const response = await axios.get(`${API_URL}/reservations/`);
        setReservations(response.data);
      } catch (error) {
        console.error('Error fetching reservations:', error);
        setMessage('Error fetching reservations. Please try again.');
      }
    };

    fetchReservations();
  }, []);

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Construct reservation data
    const reservationData = {
      name,
      email,
      date,
      time,
      guests,
    };

    try {
      // Send reservation request to backend
      const response = await axios.post(`${API_URL}/reservations/create/`, reservationData);
      if (response.status === 201) {
        setMessage('Reservation successful!');
        // Refresh reservations list
        const updatedResponse = await axios.get(`${API_URL}/reservations/`);
        setReservations(updatedResponse.data);
        // Clear form fields
        setName('');
        setEmail('');
        setDate('');
        setTime('');
        setGuests('');
      }
    } catch (error) {
      console.error('Error making reservation:', error);
      setMessage('Error making reservation. Please try again.');
    }
  };

  return (
    <section id="reservation" className="p-6 bg-gray-100 flex flex-col items-center min-h-screen">
      <div className="max-w-lg w-full bg-white p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold mb-4">Make a Reservation</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-gray-700">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700">Date</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700">Time</label>
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700">Number of Guests</label>
            <input
              type="number"
              value={guests}
              onChange={(e) => setGuests(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded"
              required
            />
          </div>
          <button type="submit" className="w-full p-2 bg-blue-600 text-white rounded">Reserve</button>
        </form>
        {message && <p className="mt-4 text-lg font-semibold">{message}</p>}
      </div>

      {/* Reservations Table */}
      <div className="max-w-4xl w-full bg-white p-6 rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold mb-4">All Reservations</h2>
        {reservations.length > 0 ? (
          <table className="w-full border-collapse border border-gray-200">
            <thead>
              <tr>
                <th className="border border-gray-300 p-2">Name</th>
                <th className="border border-gray-300 p-2">Email</th>
                <th className="border border-gray-300 p-2">Date</th>
                <th className="border border-gray-300 p-2">Time</th>
                <th className="border border-gray-300 p-2">Guests</th>
              </tr>
            </thead>
            <tbody>
              {reservations.map((reservation, index) => (
                <tr key={index}>
                  <td className="border border-gray-300 p-2">{reservation.name}</td>
                  <td className="border border-gray-300 p-2">{reservation.email}</td>
                  <td className="border border-gray-300 p-2">{reservation.date}</td>
                  <td className="border border-gray-300 p-2">{reservation.time}</td>
                  <td className="border border-gray-300 p-2">{reservation.guests}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No reservations found.</p>
        )}
      </div>
    </section>
  );
};

export default Reservation;