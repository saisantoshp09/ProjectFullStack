// components/Contact.js
export default function Contact() {
    return (
      <section id="contact" className="py-20 text-center">
        <h2 className="text-3xl font-bold mb-4">Contact Us</h2>
        <p className="text-gray-700 mb-6">Get in touch with us to learn more about our services.</p>
        <a href="mailto:info@yourbrand.com" className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600">Email Us</a>
      </section>
    );
  }
  