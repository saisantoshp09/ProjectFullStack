// components/About.js
export default function About() {
  return (
    <section id="about" className="py-20">
      <h2 className="text-3xl font-bold mb-4">About Us</h2>
      <p className="text-gray-700 mb-6">
      Hot Rock Restaurant is a fine dining establishment offering a unique culinary experience. Our chefs use the freshest ingredients to create dishes that will tantalize your taste buds. Join us for a meal you won't forget.
      </p>
    </section>
  );
}
