// src/components/Header.js
import { FaHome, FaList, FaCalendarAlt, FaMapMarkerAlt, FaStar } from 'react-icons/fa';

export default function Header() {
  return (
    <header className="p-4 bg-white shadow-md sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="text-2xl font-bold">Hot Rock Restaurant</div>
        <ul className="flex space-x-6">
          <li><a href="#about" className="flex items-center hover:text-red-500"><FaHome className="mr-1" /> About</a></li>
          <li><a href="#menu" className="flex items-center hover:text-red-500"><FaList className="mr-1" /> Menu</a></li>
          <li><a href="#reservations" className="flex items-center hover:text-red-500"><FaCalendarAlt className="mr-1" /> Reservations</a></li>
          <li><a href="#location" className="flex items-center hover:text-red-500"><FaMapMarkerAlt className="mr-1" /> Location</a></li>
          <li><a href="#testimonials" className="flex items-center hover:text-red-500"><FaStar className="mr-1" /> Testimonials</a></li>
        </ul>
      </nav>
    </header>
  );
}
